-- ============================================================
-- SCRIPT DE CRIAÇÃO DO BANCO DE DADOS: SISTEMA DE VENDAS
-- ============================================================

-- 1. Criação e seleção do Banco de Dados
DROP DATABASE IF EXISTS sistema_vendas;
CREATE DATABASE sistema_vendas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_vendas;

-- 2. Tabela de Clientes
CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefone VARCHAR(20),
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Tabela de Produtos
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10, 2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

-- 4. Tabela de Vendas (Cabeçalho da Venda)
CREATE TABLE vendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    data_venda DATETIME DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    CONSTRAINT fk_vendas_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
) ENGINE=InnoDB;

-- 5. Tabela de Itens da Venda
CREATE TABLE itens_venda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    venda_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    CONSTRAINT fk_itens_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE,
    CONSTRAINT fk_itens_produto FOREIGN KEY (produto_id) REFERENCES produtos(id)
) ENGINE=InnoDB;

-- ============================================================
-- DADOS INICIAIS DE TESTE
-- ============================================================

-- Inserindo Clientes
INSERT INTO clientes (nome, cpf, email, telefone) VALUES
('Ana Silva', '111.222.333-44', 'ana.silva@email.com', '(11) 98765-4321'),
('Carlos Souza', '555.666.777-88', 'carlos.souza@email.com', '(21) 99876-5432');

-- Inserindo Produtos
INSERT INTO produtos (nome, descricao, preco, estoque) VALUES
('Notebook Gamer', 'Intel i7, 16GB RAM, SSD 512GB', 4500.00, 10),
('Mouse Sem Fio', 'Mouse óptico ergonômico 2.4GHz', 89.90, 50),
('Teclado Mecânico', 'Switch Azul com iluminação RGB', 250.00, 30);

-- Registrando uma Venda
INSERT INTO vendas (cliente_id, total) VALUES (1, 4679.80);

-- Inserindo os Itens da Venda
INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco_unitario, subtotal) VALUES
(1, 1, 1, 4500.00, 4500.00),
(1, 2, 2, 89.90, 179.80);

-- Baixa Automática no Estoque
UPDATE produtos SET estoque = estoque - 1 WHERE id = 1;
UPDATE produtos SET estoque = estoque - 2 WHERE id = 2;

-- ============================================================
-- CONSULTAS DE VERIFICAÇÃO
-- ============================================================

-- Ver estoque atualizado
SELECT id, nome, preco, estoque FROM produtos;

-- Ver relatório detalhado da venda
SELECT 
    v.id AS nro_venda,
    v.data_venda,
    c.nome AS cliente,
    p.nome AS produto,
    iv.quantidade,
    iv.preco_unitario,
    iv.subtotal,
    v.total AS valor_total_venda
FROM vendas v
JOIN clientes c ON v.cliente_id = c.id
JOIN itens_venda iv ON iv.venda_id = v.id
JOIN produtos p ON iv.produto_id = p.id;