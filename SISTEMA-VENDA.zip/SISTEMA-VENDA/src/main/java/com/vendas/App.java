package com.vendas;

import com.vendas.dao.ClienteDAO;
import com.vendas.dao.ProdutoDAO;
import com.vendas.dao.VendaDAO;
import com.vendas.model.Cliente;
import com.vendas.model.Produto;
import com.vendas.model.Venda;

import java.util.List;

public class App {
    public static void main(String[] args){
        try{
            System.out.println("---TESTANDO O SISTEMA DE VENDAS---");
            ClienteDAO clienteDAO = new ClienteDAO();
            ProdutoDAO produtoDAO = new ProdutoDAO();
            VendaDAO vendaDAO = new VendaDAO();

            //Listar Clientes
            List<Cliente> clientes = clienteDAO.listar();

            System.out.println("\nClientes cadastrados:");
            for(Cliente c : clientes){
                System.out.println(c.getId() + " - " + c.getNome() + "(" + c.getEmail() + ")");
            }

            //Listar Produtos
            List<Produto> produtos = produtoDAO.listar();
            System.out.println("\nProdutos disponíveis:");
            for(Produto p : produtos){
                System.out.println(p.getId() + " - " + p.getNome() + "| R$" + p.getPreco() + "| Estoque: " + p.getEstoque());
            }

            //Simular uma nova Venda para o primeiro cliente
            if(!clientes.isEmpty() && produtos.size() >=2){
                Cliente clienteSelecionado = clientes.get(0);
                Produto p1 = produtos.get(0);//Notebook Gamer
                Produto p2 = produtos.get(1);//Mouse sem fio

                Venda novaVenda = new Venda(clienteSelecionado);
                novaVenda.adicionarItem(p1, 1);
                novaVenda.adicionarItem(p2,2 );
                System.out.println("\nProcessando nova venda para " + clienteSelecionado.getNome() +"..." );
                System.out.println("Valor total: R$" + novaVenda.getTotal());

                vendaDAO.realizarVenda(novaVenda);

            }


        }catch(Exception e){
            System.out.println("Erro deurante a Execução: " + e.getMessage());
            e.printStackTrace();
        }
    }    
}
