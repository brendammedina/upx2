package com.vendas.dao;

import com.vendas.model.ItemVenda;
import com.vendas.model.Venda;
import com.vendas.util.ConexaoFactory;

import java.sql.*;

public class VendaDAO {

    public void realizarVenda(Venda venda) throws SQLException {
        String sqlVenda = "INSERT INTO vendas (cliente_id, total) VALUES (?, ?)";
        String sqlItem = "INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";
        String sqlEstoque = "UPDATE produtos SET estoque = estoque - ? WHERE id = ?";

        Connection conn = null;

        try {
            conn = ConexaoFactory.getConexao();
            // Inicia a transacao manual
            conn.setAutoCommit(false);

            // 1. Inserir a Venda
            try (PreparedStatement stmtVenda = conn.prepareStatement(sqlVenda, Statement.RETURN_GENERATED_KEYS)) {
                stmtVenda.setInt(1, venda.getCliente().getId());
                stmtVenda.setDouble(2, venda.getTotal());
                stmtVenda.executeUpdate();

                ResultSet rsKey = stmtVenda.getGeneratedKeys();
                if (rsKey.next()) {
                    venda.setId(rsKey.getInt(1));
                }
            }

            // 2. Inserir os Itens e Atualizar Estoque
            try (PreparedStatement stmtItem = conn.prepareStatement(sqlItem);
                 PreparedStatement stmtEstoque = conn.prepareStatement(sqlEstoque)) {

                for (ItemVenda item : venda.getItens()) {
                    // Item da venda
                    stmtItem.setInt(1, venda.getId());
                    stmtItem.setInt(2, item.getProduto().getId());
                    stmtItem.setInt(3, item.getQuantidade());
                    stmtItem.setDouble(4, item.getPrecoUnitario());
                    stmtItem.setDouble(5, item.getSubtotal());
                    stmtItem.executeUpdate();

                    // Baixa estoque
                    stmtEstoque.setInt(1, item.getQuantidade());
                    stmtEstoque.setInt(2, item.getProduto().getId());
                    stmtEstoque.executeUpdate();
                }
            }

            // Confirma todas as alteracoes
            conn.commit();
            System.out.println("✅ Venda #" + venda.getId() + " registrada com sucesso e estoque atualizado!");

        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback(); // Cancela tudo se houver erro
                System.err.println("❌ Erro na transação! Rollback executado.");
            }
            throw e;
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }
}