package com.vendas.model;

import java.util.ArrayList;
import java.util.List;;

public class Venda {
    private  int id;
    private Cliente cliente;
    private double total;
    private List<ItemVenda> itens = new ArrayList<>();

    public Venda(Cliente cliente){
        this.cliente = cliente;
    }
    public void adicionarItem(Produto produto, int quantidade){
        ItemVenda item = new ItemVenda(produto, quantidade);
        itens.add(item);
        total += item.getSubtotal();
    }
    public int getId(){
        return  id;
    }
    public void setId(int id){
        this.id = id;
    }
    public  Cliente getCliente(){
        return cliente;
    }
    public double getTotal(){
        return total;
    }
    public List<ItemVenda>getItens(){
        return itens;
    }





}
